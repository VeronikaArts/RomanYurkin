﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FontDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_FontDemoTYPE                130
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        205
#define ID_VIEW_APPLOOK_OFF_XP          206
#define ID_VIEW_APPLOOK_WIN_XP          207
#define ID_VIEW_APPLOOK_OFF_2003        208
#define ID_VIEW_APPLOOK_VS_2005         209
#define ID_VIEW_APPLOOK_VS_2008         210
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define ID_VIEW_APPLOOK_WINDOWS_7       219
#define IDD_DIALOG1                     310
#define IDC_BOLD                        1001
#define IDC_ITALIC                      1002
#define IDC_LEFT                        1003
#define IDC_CENTER                      1004
#define IDC_RIGHT                       1005
#define IDC_UNDERLINE                   1006
#define IDC_VARIABLE                    1007
#define IDC_FIXED                       1008
#define IDC_EDIT1                       1009
#define IDC_SPACING                     1009
#define IDC_SAMPLE                      1010
#define ID_TEXT_FORMAT                  32771
#define ID_TEXT_EXIT                    32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
