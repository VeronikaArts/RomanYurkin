package com.company;

import humans.Human;
import humans.Schoolboy;
import humans.Student;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        //стип школьникку: мат,рус,ист,англ-5, оаст 4+ и первое в школьной, призовое в городской, участник областной
        Schoolboy Ivan=new Schoolboy(12,"М","Иван","первое место","участник","участник",
                true,true);//1
        Schoolboy Oleg=new Schoolboy(15,"М","Олег","-","-","-",
                false,true);
        Schoolboy Evgeny=new Schoolboy(15,"М","Евгений","первое место","-","-",
                false,true);
        Schoolboy Masha=new Schoolboy(13,"Ж","Маша","первое место","участник","-",
                false,true);
        Schoolboy Vika=new Schoolboy(16,"Ж","Вика","первое место","первое место","участник",
                true,true);//1
        Schoolboy Diana=new Schoolboy(16,"Ж","Диана","-","-","-",
                false,true);

        ArrayList<Schoolboy> schoolboysArray=new ArrayList<>();
        schoolboysArray.add(Ivan);
        schoolboysArray.add(Oleg);
        schoolboysArray.add(Evgeny);
        schoolboysArray.add(Masha);
        schoolboysArray.add(Vika);
        schoolboysArray.add(Diana);

        //стип судента: средний балл 4,75+ и курсавая на 5
        Student Valera=new Student(22,"М","Валера",0,4.0);
        Student Ksenia=new Student(20,"Ж","Ксения",4,4.75);
        Student Daniil=new Student(21,"М","Даниил",5,4.75);//1
        Student Liza=new Student(22,"Ж","Лиза",5,5);//1
        Student Roma=new Student(20,"М","Рома",0,3);
        Student Dasha=new Student(21,"Ж","Даша",4,4.0);

        ArrayList<Student> studentArray=new ArrayList<>();
        studentArray.add(Valera);
        studentArray.add(Ksenia);
        studentArray.add(Daniil);
        studentArray.add(Liza);
        studentArray.add(Roma);
        studentArray.add(Dasha);

        ArrayList<Human> isScholarship=new ArrayList<>();

        System.out.println("Девочки, получившие первые места на олимпиадах:");
        for (int i=0;i<schoolboysArray.size();i++){
            if(schoolboysArray.get(i).getGender().equals("Ж") && (schoolboysArray.get(i).getIsOlympiadSchool().equals("первое место") ||
                    schoolboysArray.get(i).getIsOlympiadRegional().equals("первое место") ||
                    schoolboysArray.get(i).getIsOlympiadUrban().equals("первое место")) )
                System.out.println(schoolboysArray.get(i).toString());

            if (schoolboysArray.get(i).IsScholarship()){
                isScholarship.add(schoolboysArray.get(i));
            }
        }

        System.out.println("Студенты, получившие оценки за курсовые работы:");
        for (int i=0;i<studentArray.size();i++){
            if(studentArray.get(i).getaverageCoursework()>2.0)
                System.out.println(studentArray.get(i).toString());

            if (studentArray.get(i).IsScholarship()){
                isScholarship.add(studentArray.get(i));
            }
        }

        System.out.println("Школьники и студенты, которые должны получать спец. стипендию:");
        for (int i=0;i<isScholarship.size();i++){
            System.out.println(isScholarship.get(i).toString());
        }















    }
}
