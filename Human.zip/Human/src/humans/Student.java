package humans;

import java.util.HashMap;
import java.util.Map;

public class Student extends Human {

    private double averageCoursework;
    //средний балл
    private double averageScore;

    public Student(int age,String gender, String name,double averageCoursework,double averageScore){
        super(age,gender, name);
        this.averageScore=averageScore;
        this.averageCoursework=averageCoursework;

    }

    public double getaverageCoursework(){
        return this.averageCoursework;
    }
    public void setCourseworkFive(double averageCoursework){
        this.averageCoursework=averageCoursework;
    }

    public double getAverageScore(){
        return this.averageScore;
    }
    public void setAverageScore(double averageScore){
        this.averageScore=averageScore;
    }

    @Override
    public boolean IsScholarship(){
        if (this.averageScore>=4.75 && this.averageCoursework==5)
            return true;
        else return super.IsScholarship();
    }

    public String toString(){
        return super.toString()+", средний балл: "+averageScore+", оценка за курсовую: "+averageCoursework;
    }





}
