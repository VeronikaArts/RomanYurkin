package humans;

public class Human {
    private String name;
    private String gender;
    private int age;

    public Human(Human human){
        this.age =human.age;
        this.name=human.name;
        this.gender=human.gender;
    }

    public Human(int age,String gender, String name){
        this.age=age;
        this.gender=gender;
        this.name=name;
    }

    public Human(){
        this.age=0;
        this.gender="";
        this.name="";
    }

    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return this.name;
    }

    public void setAge(int age){
        this.age=age;
    }
    public int getAge(){return this.age;}

    public String getGender(){
        return this.gender;
    }

    public void setGender(String gender){
        this.gender=gender;
    }

    public boolean IsScholarship(){
        return false;
    }

    public String toString(){
        return "Имя: "+name+", пол: "+gender+", возраст: "+age;
    }








}
