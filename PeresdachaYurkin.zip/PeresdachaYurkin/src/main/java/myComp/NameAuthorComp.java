package myComp;

import book.Book;

import java.util.Comparator;


public class NameAuthorComp implements Comparator<Book>{

    @Override
    public int compare(Book K, Book T){

        return K.getName_generator().compareTo(T.getName_generator());

    }
}
