package myComp;

import book.Book;

import java.util.Comparator;

public class PagesComp implements Comparator<Book> {
    @Override
    public int compare(Book K, Book T){
        if(K.getPages()>T.getPages())
            return 1;
        else {
            if(K.getPages()==T.getPages())
                return 0;
            else return -1;
        }
    }
}
