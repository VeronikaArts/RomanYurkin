package myComp;

import book.Book;

import java.util.Comparator;

public class PriceComp implements Comparator<Book> {
    @Override
    public int compare(Book K, Book T){
        if(K.getPrice()>T.getPrice())
            return 1;
        else {
            if(K.getPrice()==T.getPrice())
                return 0;
            else return -1;
        }


    }
}
