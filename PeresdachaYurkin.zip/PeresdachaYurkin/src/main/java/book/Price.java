package book;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Price {

    private SimpleDoubleProperty priceMin;
    private SimpleDoubleProperty priceMax;

    public DoubleProperty priceMinDoubleProperty() {
        if (priceMin == null) {
            priceMin= new SimpleDoubleProperty();
        }
        return priceMin;
    }
    public final void setPrice(Double value) { priceMinDoubleProperty().set(value); }
    public final double getPrice() {
        return priceMinDoubleProperty().get();
    }

    public DoubleProperty priceMaxDoubleProperty() {
        if (priceMax == null) {
            priceMax= new SimpleDoubleProperty();
        }
        return priceMax;
    }
    public final void setPriceMax(Double value) { priceMaxDoubleProperty().set(value); }
    public final double getPriceMax() {
        return priceMaxDoubleProperty().get();
    }

    public Price( double price, double priceMax){

        priceMinDoubleProperty().set(price);
        priceMaxDoubleProperty().set(priceMax);
    }
    public Price(){return;}


}
