package book;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import myComp.PagesComp;
import myComp.PriceComp;
import myComp.NameAuthorComp;

import java.io.*;
import java.util.stream.Collectors;


public class Main  extends Application {

    private TableView<Book> table = new TableView<>();
    //private TableView<Book> tableZakaz = new TableView<>();
    private String errorMessage="";

    private ObservableList<Price> pr= FXCollections.observableArrayList();
    private ObservableList<Book> data= FXCollections.observableArrayList();
   // private ObservableList<Book> dataZakaz= FXCollections.observableArrayList(new Book("In total:","",0,0));

    private void showMessage(String message){
        Alert mess = new Alert(Alert.AlertType.WARNING,message,ButtonType.OK);
        mess.showAndWait();
    }

    private void handleFileOpen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open file to read data");
        File file = fileChooser.showOpenDialog(null);
        if (file == null) {
            return;
        }
        readDataFromFile(file);
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
    }
    private void readDataFromFile(File dataFile) {

        try {
            data.clear();
            errorMessage="";
            BufferedReader in = new BufferedReader(new FileReader(dataFile));
            String str;
            while ((str = in.readLine()) != null) {
                try {
                    if(str.isEmpty()) break;
                    String[] dataArray = str.split(" +");
                    if (dataArray.length != 3)
                        throw new Exception("Wrong data");
                    String name_book = dataArray[0];
                    int pg = Integer.parseInt(dataArray[1]);
                    double price = Double.parseDouble(dataArray[2]);
                    String name_gen = in.readLine();
                    if (name_gen == null || name_gen.isEmpty())
                        throw new Exception("wrong");
                    Book prod= new Book(name_book,name_gen,price,pg);
                    data.add(prod);

                } catch (Exception e){
                    errorMessage+=e.getMessage()+"\n";
                    in.close();
                }
            }

            in.close();
        } catch (IOException e){
            errorMessage+=e.getMessage()+"\n";
        }

        NameAuthorComp compNameP= new NameAuthorComp();
        PriceComp priceComp = new PriceComp();
        data.sort(compNameP.thenComparing(priceComp).thenComparing((K, T)->(K.getName_generator().compareTo(T.getName_generator()))));
    }


    @Override
    public void init() {
        readDataFromFile(new File("src/main/java/book/book.txt"));
    }

    private void createTable() {
        TableColumn name1 = new TableColumn("Book's name");
        name1.setMinWidth(150);
        name1.setCellValueFactory(new PropertyValueFactory<Book, String>("name_product"));
        name1.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn name2 = new TableColumn("Manufacturer's name");
        name2.setMinWidth(180);
        name2.setCellValueFactory(new PropertyValueFactory<Book, String>("name_generator"));
        name2.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn price = new TableColumn("Price");
        price.setMinWidth(120);
        price.setCellValueFactory(new PropertyValueFactory<Book, Double>("price"));
        price.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));

        TableColumn pages = new TableColumn("Pages");
        pages.setMinWidth(120);
        pages.setCellValueFactory(new PropertyValueFactory<Book, Integer>("pages"));
        pages.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        table.setItems((ObservableList<Book>) data);
        table.getColumns().addAll(name1,name2,price,pages);
        table.setMaxSize(820,400);
    }

    private void createTableZakaz(TableView<Book> tableZakaz,ObservableList<Book> dataFilter) {
        TableColumn name1 = new TableColumn("Book");
        name1.setMinWidth(150);
        name1.setCellValueFactory(new PropertyValueFactory<Book, String>("name_product"));
        name1.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn name2 = new TableColumn("Manufacturer's name");
        name2.setMinWidth(180);
        name2.setCellValueFactory(new PropertyValueFactory<Book, String>("name_generator"));
        name2.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn price = new TableColumn("Price");
        price.setMinWidth(120);
        price.setCellValueFactory(new PropertyValueFactory<Book, Double>("price"));
        price.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));

        tableZakaz.setItems(dataFilter);
        tableZakaz.getColumns().addAll(name1,name2,price);
        tableZakaz.setMaxSize(820,400);
    }
    private void handleButtonEdit() {
        Book p = table.getSelectionModel().getSelectedItem();
        if (p != null) {
            BookEditDialog pEditDialog = new BookEditDialog(p,"Edit product information");
            table.refresh();
        } else {
            showMessage("Item not selected");
        }
    }

    private void handleButtonAdd() {
        Book p= new Book("", "", 0.1,0);
        BookEditDialog petEdit=new BookEditDialog(p,"Adding a product");
        if (petEdit.getResult() == ButtonType.OK) {
            data.add(p);
        }
    }

    private void handleButtonDelete() {
        int selectedIndex = table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            table.getItems().remove(selectedIndex);
        } else {
            showMessage("Unable to delete item");
        }
    }

    private Menu createFileMenu() {
        Menu fileMenu = new Menu("File");
        MenuItem open = new MenuItem("Open");
        MenuItem exit = new MenuItem("Exit");
        fileMenu.getItems().addAll(open, new SeparatorMenuItem(), exit);
        open.setOnAction((ActionEvent event) -> handleFileOpen());
        exit.setOnAction((ActionEvent event) ->Platform.exit());
        return fileMenu;
    }

    private Menu createEditMenu() {
        Menu editMenu = new Menu("Edit");

        MenuItem add = new MenuItem("Add product");
        editMenu.getItems().add(add);
        add.setOnAction((ActionEvent event) -> handleButtonAdd());

        MenuItem edit = new MenuItem("Edit product information");
        editMenu.getItems().add(edit);
        edit.setOnAction((ActionEvent event) -> handleButtonEdit());

        MenuItem delete = new MenuItem("Delete product");
        editMenu.getItems().add(delete);
        delete.setOnAction((ActionEvent event) -> handleButtonDelete());

        return editMenu;
    }

    //TODO sort price/pages
    private Menu createShowSortMenu() {
        Menu showMenu = new Menu("Selection");

        Menu selection = new Menu("Selecting books by the name of author");
        MenuItem menuItem11 = new MenuItem("Sort pages");
        selection.getItems().add(menuItem11);

        menuItem11.setOnAction((ActionEvent e) -> {
            Book book = table.getSelectionModel().getSelectedItem();
            if (book != null) {
                ObservableList<Book> dataShow = FXCollections.observableArrayList();
                dataShow.setAll(data.stream().filter(book1 -> book1.isName_Author(book)).collect(Collectors.toList()));
                PagesComp pagesComparator = new PagesComp();
                PriceComp priceComparator = new PriceComp();
                dataShow.sort(pagesComparator.reversed().thenComparing(priceComparator));
                table.setItems(dataShow);
            } else {
                showMessage("No selected item!");
            }
        });

        MenuItem menuItem12 = new MenuItem("Sort price");
        selection.getItems().add(menuItem12);

        menuItem12.setOnAction((ActionEvent e) -> {
            Book goods = table.getSelectionModel().getSelectedItem();
            if (goods != null) {
                ObservableList<Book> dataShow = FXCollections.observableArrayList();
                dataShow.setAll(data.stream().filter(goods1 -> goods1.isName_Author(goods)).collect(Collectors.toList()));
                PagesComp pagesComparator = new PagesComp();
                PriceComp priceComparator = new PriceComp();
                dataShow.sort(pagesComparator.thenComparing(priceComparator));

                table.setItems(dataShow);
            } else {
                showMessage("No selected item!");
            }
        });

        MenuItem showAll= new MenuItem("Cancel selection");
        showAll.setOnAction((ActionEvent e) -> table.setItems(data));

        showMenu.getItems().addAll(selection,showAll);
        return showMenu;
    }


    private Menu createShowPriceMenu() {
        Menu showMenu = new Menu("Choose price");

        MenuItem edit = new MenuItem("price");
        showMenu.getItems().add(edit);
        edit.setOnAction((ActionEvent event) -> {

            ObservableList<Book> dataFilter = FXCollections.observableArrayList();
            Price price= new Price(0,0);
            PriceAddDialog price_Edit=new PriceAddDialog(price);
            if (price_Edit.getResult() == ButtonType.OK) {
                pr.set(0,price);
                for (int i =0;i<data.size();i++){
                    if(data.get(i).getPrice()>=pr.get(0).getPrice() && data.get(i).getPrice()<=pr.get(0).getPriceMax()){
                        dataFilter.add(data.get(i));
                    }
                }

                dataFilterView(dataFilter);
            }
        });//������ �������

        showMenu.getItems().addAll(edit);
        return showMenu;
    }

   /* private void handleButtonPrice(){

        ObservableList<Book> dataFilter = FXCollections.observableArrayList();
        Price price= new Price(0,0);
        PriceAddDialog price_Edit=new PriceAddDialog(price);
        if (price_Edit.getResult() == ButtonType.OK) {
            pr.set(0,price);
        }
        for (int i =0;i<data.size();i++){
            if(data.get(i).getPrice()>=pr.get(0).getPrice() && data.get(i).getPrice()<=pr.get(0).getPriceMax()){
                dataFilter.add(data.get(i));
            }
        }
        dataFilterView(dataFilter);

    }*/
    private void dataFilterView (ObservableList<Book> dataFilter){
        Stage view = new Stage();
        view.setTitle("books authors price");
        TableView<Book> table1 = new TableView<>();
        createTableZakaz(table1,dataFilter);
        table1.setItems(dataFilter);
        Button ok = new Button("Ok");
        ok.setOnAction( e-> view.close());

        VBox root = new VBox();
        root.setPadding(new Insets(10));
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(table1, ok);
        view.setScene(new Scene(root, 800, 450));
        view.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    @Override

    public void start(Stage primaryStage) {
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
        primaryStage.setTitle("Book");

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));

        createTable();
        //createTableZakaz();

        table.setItems(data);
        table.setPadding(new Insets(10));
        root.setCenter(table);

        //root.setRight(tableZakaz);

        root.setTop(new MenuBar(createFileMenu(), createEditMenu(),createShowSortMenu(),createShowPriceMenu()));

        Scene scene = new Scene(root,900, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
