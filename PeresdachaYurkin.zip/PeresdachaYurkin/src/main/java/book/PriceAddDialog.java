package book;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PriceAddDialog {

    private Price p;
    private Stage dialog;
    private Spinner<Double> priceMinEdit;
    private Spinner<Double> priceMaxEdit;

    private Font font;
    private GridPane root;
    private ButtonType result = ButtonType.CANCEL;



    private void createSpinnerMin() {
        Label pricce = new Label("Price :");
        pricce.setFont(font);
        root.add(pricce, 0, 3);
        priceMinEdit=new Spinner<>(0, 1000, 0,0.2);

        priceMinEdit.setStyle("-fx-font-size: 24 pt");
        priceMinEdit.setEditable(true);
        root.add(priceMinEdit, 1, 3);

    }

    private void createSpinnerMax() {
        Label pricce = new Label("Price :");
        pricce.setFont(font);
        root.add(pricce, 0, 2);
        priceMaxEdit=new Spinner<>(0, 1000, 0,0.2);

        priceMaxEdit.setStyle("-fx-font-size: 24 pt");
        priceMaxEdit.setEditable(true);
        root.add(priceMaxEdit, 1, 2);

    }

    public PriceAddDialog(Price p) {
        this.p = p;
        dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        //dialog.setTitle(title);

        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10);
        root.setVgap(10);
        font = Font.font("Tahoma", FontWeight.NORMAL, 20);

        createSpinnerMin();
        createSpinnerMax();
        createButtons();

        Scene scene = new Scene(root, 600, 500);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void createButtons() {
        Button btnOk = new Button("Ok");
        btnOk.setFont(Font.font(24));
        root.add(btnOk, 0, 4);
        btnOk.setOnAction((ActionEvent e) -> handleOk());

        btnOk.setOnAction((ActionEvent e) -> {
            if ((Double.parseDouble(priceMinEdit.toString())< Double.parseDouble(priceMaxEdit.toString())))
                handleOk();
            else message();
        });

        Button btnCancel = new Button("Cancel");
        btnCancel.setFont(Font.font(24));
        root.add(btnCancel, 1, 4);
        btnCancel.setOnAction((ActionEvent e) -> {
            handleCancel();
        });
    }


    private void message(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid input");
        alert.setHeaderText(null);
        alert.setContentText("Invalid input");
        alert.showAndWait();
    }

    private void handleOk() {
        p.setPrice(priceMinEdit.getValue());
        p.setPriceMax(priceMaxEdit.getValue());
        result = ButtonType.OK;
        dialog.close();
    }

    private Double getPriceMin(){
        return Double.parseDouble(priceMinEdit.toString()) ;
    }

    private Double getPriceMax(){
        return Double.parseDouble(priceMaxEdit.toString()) ;
    }

    private void handleCancel() {
        priceMinEdit=null;
        result = ButtonType.CANCEL;
        dialog.close();
    }

    public ButtonType getResult() {
        return result;
    }



}
