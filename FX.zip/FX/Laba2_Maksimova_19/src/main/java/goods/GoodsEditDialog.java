package goods;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class GoodsEditDialog {
    private Goods pr;
    private Stage dialog;
    private TextField name_goodsEdit;
    private TextField name_provderEdit;
    private Spinner<Double> priceEdit;
    private Spinner<Integer> amountEdit;
    private TextField name_shopEdit;

    private Font font;
    private GridPane root;
    private ButtonType result = ButtonType.CANCEL;

    private void createProductText() {
        Label name = new Label("Goods name:");
        name.setFont(font);
        root.add(name, 0, 1);
        name_goodsEdit = new TextField();
        name_goodsEdit.setFont(Font.font(24));
        name_goodsEdit.setText(pr.getName_goods());
        root.add(name_goodsEdit, 1, 1);
        if(pr!=null){
            name_goodsEdit.setText(pr.getName_goods());
        }
    }

    private void createGenerationText() {
        Label nameG = new Label("Provider's name:");
        nameG.setFont(font);
        root.add(nameG, 0, 2);
        name_provderEdit = new TextField();
        name_provderEdit.setFont(Font.font(24));
        name_provderEdit.setText(pr.getName_provider());
        root.add(name_provderEdit, 1, 2);
        if(pr!=null){
            name_provderEdit.setText(pr.getName_provider());
        }
    }

    private void createSpinner() {
        Label pricce = new Label("Price:");
        pricce.setFont(font);
        root.add(pricce, 0, 3);
        if(pr!=null)
            priceEdit=new Spinner<>(0, 1000, pr.getPrice(),0.2);
        else
            priceEdit=new Spinner<>(0, 1000, 0);

        priceEdit.setStyle("-fx-font-size: 24 pt");
        priceEdit.setEditable(true);
        root.add(priceEdit, 1, 3);

        Label amo = new Label("Amount:");
        amo.setFont(font);
        root.add(amo, 0, 4);
        if(pr!=null)
            amountEdit=new Spinner<>(0, 1000, pr.getAmount(),1);
        else
             amountEdit=new Spinner<>(0, 1000, 0);

        amountEdit.setStyle("-fx-font-size: 24 pt");
        amountEdit.setEditable(true);
        root.add(amountEdit, 1, 4);

    }

    private void createSText() {
        Label s = new Label("Name of shop:");
        s.setFont(font);
        root.add(s, 0, 5);
        name_shopEdit = new TextField();
        name_shopEdit.setFont(Font.font(24));
        name_shopEdit.setText(pr.getName_shop());
        root.add(name_shopEdit, 1, 5);
        if(pr!=null){
            name_shopEdit.setText(pr.getName_shop());
        }
    }

    private void createButtons() {
        Button btnOk = new Button("Ok");
        btnOk.setFont(Font.font(24));
        root.add(btnOk, 0, 6);
        btnOk.setOnAction((ActionEvent e) -> handleOk());

        Button btnCancel = new Button("Cancel");
        btnCancel.setFont(Font.font(24));
        root.add(btnCancel, 1, 6);
        btnCancel.setOnAction((ActionEvent e) -> {
            handleCancel();
        });
    }

    public GoodsEditDialog(Goods p,String title) {
        this.pr = p;
        dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle(title);

        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10);
        root.setVgap(10);
        font = Font.font("Tahoma", FontWeight.NORMAL, 20);

        createProductText();
        createGenerationText();
        createSText();
        createSpinner();
        createButtons();

        Scene scene = new Scene(root, 600, 500);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void handleOk() {
        pr.setName_goods(name_goodsEdit.getText());
        pr.setName_provider(name_provderEdit.getText());
        pr.setPrice(priceEdit.getValue());
        pr.setAmount(amountEdit.getValue());
        pr.setName_shop(name_shopEdit.getText());
        result = ButtonType.OK;
        dialog.close();
    }

    private void handleCancel() {
        pr=null;
        result = ButtonType.CANCEL;
        dialog.close();
    }

    public ButtonType getResult() {
        return result;
    }

}
