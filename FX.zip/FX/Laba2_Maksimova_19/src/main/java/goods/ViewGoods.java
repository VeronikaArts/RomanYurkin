package goods;

import javafx.geometry.Insets;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class ViewGoods {
    private  Goods goods;
    private StackPane pane;

    public ViewGoods () {
        createPane();
    }

    private  void createPane(){
        pane = new StackPane();
        pane.setPadding(new Insets(2));
        Rectangle rect = new Rectangle(200, 200);
        rect.setFill(Color.AZURE);
        rect.setStroke(Color.BLUEVIOLET);
        rect.setStrokeWidth(3);
        pane.getChildren().add(rect);
        Text textGoods = new Text();
        pane.getChildren().add(textGoods);
    }

    public void setGoods(Goods goods) {
        this.goods=goods;
        ((Text)pane.getChildren().get(1)).setText("Goods name: "+goods.getName_goods()+"\n"+"Provider's name: "+
                goods.getName_provider()+"\n"+"Name of shop: "+
                goods.getName_shop()+"\n"+"Price: "+goods.getPrice()+"\n"+"Amount: "+goods.getAmount());
    }

    public StackPane getPane () {
        return pane;
    }
}
