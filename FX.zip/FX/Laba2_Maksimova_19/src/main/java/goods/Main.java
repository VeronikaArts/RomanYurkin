package goods;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import myComp.NameGoodsComp;
import myComp.NameShopComp;
import myComp.PriceComp;

import java.io.*;
import java.util.stream.Collectors;

public class Main extends Application {

    private TableView<Goods> table;
    private String errorMessage="";
    ViewGoods viewGoods= new ViewGoods();
    private ObservableList<Goods> data= FXCollections.observableArrayList();

    private void showMessage(String message){
        Alert mess = new Alert(Alert.AlertType.WARNING,message, ButtonType.OK);
        mess.showAndWait();
    }

    private void handleFileOpen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open file to read data");
        File file = fileChooser.showOpenDialog(null);
        if (file == null) {
            return;
        }
        readDataFromFile(file);
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
    }

    private void readDataFromFile(File dataFile) {

        try {
            data.clear();
            errorMessage="";
            BufferedReader in = new BufferedReader(new FileReader(dataFile));
            String str;
            while ((str = in.readLine()) != null) {
                try {
                    if(str.isEmpty()) break;
                    String[] dataArray = str.split(" +");
                    if (dataArray.length != 4)
                        throw new Exception("Wrong data");
                    String name_goods = dataArray[0];
                    String name_provider = dataArray[1];
                    double price = Double.parseDouble(dataArray[2]);
                    int amount = Integer.parseInt(dataArray[3]);
                    String name_shop = in.readLine();
                    if (name_shop== null || name_shop.isEmpty())
                        throw new Exception("wrong");
                    Goods goods= new Goods(name_goods,name_provider,price,name_shop,amount);
                    data.add(goods);

                } catch (Exception e){
                    errorMessage+=e.getMessage()+"\n";
                    in.close();
                }
            }

            in.close();
        } catch (IOException e){
            errorMessage+=e.getMessage()+"\n";
        }

        NameGoodsComp nameGoodsComp= new NameGoodsComp();
        NameShopComp nameShopComp=new NameShopComp();
        PriceComp priceComp = new PriceComp();
        data.sort(nameGoodsComp.thenComparing(nameShopComp.thenComparing(priceComp).thenComparing((K,T)->(K.getName_provider().compareTo(T.getName_provider())))));
        sort(data.size());
        sort(data.size());

    }

    public void sort(int max){
        int i=1;
        while (i<max){
            if(data.get(i).getName_goods().equals(data.get(i-1).getName_goods())){
                if(data.get(i).getName_shop().equals(data.get(i-1).getName_shop())){
                    if(data.get(i).getName_provider().equals(data.get(i-1).getName_provider())){
                        if(data.get(i).getPrice()==data.get(i-1).getPrice()){
                            data.remove(i);
                            max--;
                        }
                    }

                }
            }
            i++;
        }
    }

    @Override
    public void init() {
        readDataFromFile(new File("src/main/java/goods/goods.txt"));
    }

    private void createTable() {
        TableColumn name1 = new TableColumn("Goods name");
        name1.setMinWidth(150);
        name1.setCellValueFactory(new PropertyValueFactory<Goods, String>("name_goods"));
        name1.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn name2 = new TableColumn("Provider's name");
        name2.setMinWidth(180);
        name2.setCellValueFactory(new PropertyValueFactory<Goods, String>("name_provider"));
        name2.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn name3 = new TableColumn("Name of shop");
        name3.setMinWidth(180);
        name3.setCellValueFactory(new PropertyValueFactory<Goods, String>("name_shop"));
        name3.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn price = new TableColumn("Price");
        price.setMinWidth(90);
        price.setCellValueFactory(new PropertyValueFactory<Goods, Double>("price"));
        price.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));

        TableColumn amount = new TableColumn("Amount of goods");
        amount.setMinWidth(160);
        amount.setCellValueFactory(new PropertyValueFactory<Goods, Integer>("amount"));
        amount.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        table.setItems(data);
        table.getColumns().addAll(name1,name2,name3,price,amount);
        table.setMaxSize(900,400);
    }

    private void handleButtonEdit() {
        Goods p = table.getSelectionModel().getSelectedItem();
        if (p != null) {
            GoodsEditDialog gEditDialog = new GoodsEditDialog(p,"Edit goods information");
            table.refresh();
        } else {
            showMessage("Goods not selected");
        }
    }

    private void handleButtonAdd() {
        Goods p= new Goods("","",0.1,"",1);
        GoodsEditDialog gEdit=new GoodsEditDialog(p,"Adding a product");
        if (gEdit.getResult() == ButtonType.OK) {
            data.add(p);
        }
    }

    private void handleButtonDelete() {
        int selectedIndex = table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            table.getItems().remove(selectedIndex);
        } else {
            showMessage("Unable to delete goods");
        }
    }

    private Menu createFileMenu() {
        Menu fileMenu = new Menu("File");
        MenuItem open = new MenuItem("Open");
        MenuItem exit = new MenuItem("Exit");
        fileMenu.getItems().addAll(open, new SeparatorMenuItem(), exit);
        open.setOnAction((ActionEvent event) -> handleFileOpen());
        exit.setOnAction((ActionEvent event) -> Platform.exit());
        return fileMenu;
    }

    private Menu createEditMenu() {
        Menu editMenu = new Menu("Edit");

        MenuItem add = new MenuItem("Add goods");
        editMenu.getItems().add(add);
        add.setOnAction((ActionEvent event) -> handleButtonAdd());

        MenuItem edit = new MenuItem("Edit goods information");
        editMenu.getItems().add(edit);
        edit.setOnAction((ActionEvent event) -> handleButtonEdit());

        MenuItem delete = new MenuItem("Delete goods");
        editMenu.getItems().add(delete);
        delete.setOnAction((ActionEvent event) -> handleButtonDelete());

        return editMenu;
    }

    private Menu createShowSortMenu() {
        Menu showMenu = new Menu("Selection");
        MenuItem selection = new MenuItem("Selecting products by the name of shop");

        selection.setOnAction((ActionEvent e) -> {
            Goods goods = table.getSelectionModel().getSelectedItem();
            if (goods != null) {
                ObservableList<Goods> dataShow = FXCollections.observableArrayList();
                dataShow.setAll(data.stream().filter(goods1 -> goods1.isName_Shop(goods)).collect(Collectors.toList()));
                table.setItems(dataShow);
            } else {
                showMessage("No selected item!");
            }
        });

        MenuItem showAll= new MenuItem("Cancel selection");
        showAll.setOnAction((ActionEvent e) -> table.setItems(data));

        showMenu.getItems().addAll(selection,showAll);
        return showMenu;
    }

    private TableView<Goods>createListViewOrg(){
        table= new TableView<>(data);
        table.getSelectionModel().selectedItemProperty().addListener((observable,oldValue, newValue) ->{
            if(newValue!=null)
                viewGoods.setGoods(newValue);
        });

        table.getSelectionModel().selectFirst();
        return table;
    }

    @Override
    public void start(Stage primaryStage) {
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
        primaryStage.setTitle("Goods");

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));
        root.setLeft(createListViewOrg());
        root.setRight(viewGoods.getPane());
        createTable();
        root.setTop(new MenuBar(createFileMenu(), createEditMenu(),createShowSortMenu()));

        Scene scene = new Scene(root,1000, 460);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
