package goods;

import javafx.beans.property.*;

public class Goods {

    private StringProperty name_goods;
    private StringProperty name_provider;
    private SimpleDoubleProperty price;
    private SimpleIntegerProperty amount;
    private StringProperty name_shop;


    public StringProperty name_goodsStringProprty(){
        if (name_goods ==null){
            name_goods = new SimpleStringProperty();
        }
        return name_goods;
    }
    public final void setName_goods(String value){
        name_goodsStringProprty().set(value);
    }
    public final String getName_goods() {
        return name_goodsStringProprty().get();
    }

    public StringProperty name_providerStringProperty() {
        if (name_provider == null) {
            name_provider = new SimpleStringProperty();
        }
        return name_provider;
    }
    public final void setName_provider(String value) {
        name_providerStringProperty().set(value);
    }
    public final String getName_provider() {
        return name_providerStringProperty().get();
    }

    public DoubleProperty priceDoubleProperty() {
        if (price == null) {
            price= new SimpleDoubleProperty();
        }
        return price;
    }
    public final void setPrice(Double value) { priceDoubleProperty().set(value); }
    public final double getPrice() {
        return priceDoubleProperty().get();
    }

    public IntegerProperty amountIntegerProperty() {
        if (amount == null) {
            amount= new SimpleIntegerProperty();
        }
        return amount;
    }
    public final void setAmount(Integer value) { amountIntegerProperty().set(value); }
    public final int getAmount() { return amountIntegerProperty().get(); }

    public StringProperty  name_shopStringProprty(){
        if ( name_shop ==null){
            name_shop = new SimpleStringProperty();
        }
        return name_shop;
    }
    public final void setName_shop(String value){
        name_shopStringProprty().set(value);
    }
    public final String getName_shop() {
        return  name_shopStringProprty().get();
    }

    public  boolean isName_Shop(Goods g){
        return name_shop.toString().equals(g.name_shop.toString());
    }

    public String toString(){
        return name_goods.toString()+" " + name_provider.toString()+" "+price.toString()+" "+amount.toString()+" "+ name_shop.toString();
    }

    public Goods(String name_goods, String name_provider, double price, String name_shop,int amount){
        name_goodsStringProprty().set(name_goods);
        name_providerStringProperty().set(name_provider);
        priceDoubleProperty().set(price);
        amountIntegerProperty().set(amount);
        name_shopStringProprty().set(name_shop);
    }
    public Goods(){return;}

}
