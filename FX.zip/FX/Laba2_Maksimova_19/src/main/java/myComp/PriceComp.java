package myComp;

import goods.Goods;

import java.util.Comparator;

public class PriceComp implements Comparator<Goods> {
    @Override
    public int compare(Goods K, Goods T){
        if(K.getPrice()>T.getPrice())
            return 1;
        else {
            if(K.getPrice()==T.getPrice())
                return 0;
            else return -1;
        }


    }
}