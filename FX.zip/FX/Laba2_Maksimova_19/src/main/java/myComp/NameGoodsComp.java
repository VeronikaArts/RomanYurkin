package myComp;

import goods.Goods;

import java.util.Comparator;

public class NameGoodsComp implements Comparator<Goods> {

    @Override
    public int compare(Goods K, Goods T){

        return K.getName_goods().compareTo(T.getName_goods());

    }
}