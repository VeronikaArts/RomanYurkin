package pets5;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


public class Main  extends Application {

    Pet pet;
    VBox vbox;

    private  void createSceneElements(Pet pet){
        ViewPet veiew_pet = new ViewPet(pet);
        vbox=new VBox();
        vbox.getChildren().add(veiew_pet.getPane());
        vbox.setBackground(new Background(new BackgroundFill(Color.AZURE, CornerRadii.EMPTY,Insets.EMPTY)));
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(20);
        vbox.getChildren().add(new Separator(Orientation.VERTICAL));
        vbox.setPadding(new Insets(10));

    }


    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("�������");
        BorderPane root = new BorderPane();
        pet = new Pet("������", "������", 1, 9, "���������");

        root.setStyle("-fx-font-size: 18 pt");

        createSceneElements(pet);

        MenuBar menuBar=new MenuBar();
        menuBar.getMenus().add(createFileMenu());


        SplitMenuButton menuColor =  createColorMenu();

        root.setTop(menuBar);
        root.setCenter(vbox);
        root.setBottom(menuColor);

        Scene scene = new Scene(root,450,450);
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private Menu createFileMenu(){
        Menu menuFile = new Menu("File");

        MenuItem rename = new MenuItem("�������� ����������");
        rename.setOnAction((ActionEvent e)->{
            PetEditDialog petEditDialog = new PetEditDialog(pet);
        });

        MenuItem MasterInf = new MenuItem("���������� �� ������");
        MasterInf.setOnAction((ActionEvent e)->{
            informAutor();
        });

        MenuItem exit = new MenuItem("�����");
        exit.setOnAction((ActionEvent t) -> {
            Platform.exit();
        });

        menuFile.getItems().addAll(rename, MasterInf,  new SeparatorMenuItem(), exit);
        return menuFile;
    }
    private void informAutor() {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("����� ������");
        alert.setHeaderText(null);
        alert.setContentText("����������� ��������\n ���-21��\n ����� �����, ������� � ���� �������������;)");
        alert.getDialogPane().setMinSize(200, 200);
        alert.showAndWait();

    }

    private SplitMenuButton createColorMenu() {
        MenuItem red = new MenuItem("Plum");
        red.setOnAction((ActionEvent event) -> {
            vbox.setBackground(new Background(new BackgroundFill(Color.PLUM, CornerRadii.EMPTY, Insets.EMPTY)));
        });
        MenuItem blue = new MenuItem("Tan");
        blue.setOnAction((ActionEvent event) -> {
            vbox.setBackground(new Background(new BackgroundFill(Color.TAN, CornerRadii.EMPTY, Insets.EMPTY)));
        });
        MenuItem green = new MenuItem("Khaki");
        green.setOnAction((ActionEvent event) -> {
            vbox.setBackground(new Background(new BackgroundFill(Color.KHAKI, CornerRadii.EMPTY, Insets.EMPTY)));
        });
        SplitMenuButton textColorMenu = new SplitMenuButton(red, blue, green);
        textColorMenu.setText("Select color");
        textColorMenu.setOnAction((ActionEvent event) -> {
            vbox.setBackground(new Background(new BackgroundFill(Color.AZURE, CornerRadii.EMPTY, Insets.EMPTY)));
        });
        return textColorMenu;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
