package pets4;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PetEditDialog {
    private Pet pet;
    private Stage dialog;
    private TextField nameEdit;
    private Spinner<Integer> yearEdit;
    private TextField nameMasterEdit;
    private Spinner<Integer> monthEdit;
    private ComboBox<String> kindEdit;

    private Font font;
    private GridPane root;
    private ButtonType result = ButtonType.CANCEL;

    private void createNameText() {
        Label name = new Label("��� ���������:");
        name.setFont(font);
        root.add(name, 0, 1);
        nameEdit = new TextField();
        nameEdit.setFont(Font.font(24));
        nameEdit.setText(pet.getName());
        root.add(nameEdit, 1, 1);
    }

    private void createMasterText() {
        Label Master = new Label("��� �������:");
        Master.setFont(font);
        root.add(Master, 0, 2);
        nameMasterEdit = new TextField();
        nameMasterEdit.setFont(Font.font(24));
        nameMasterEdit.setText(pet.getHost_name());
        root.add(nameMasterEdit, 1, 2);
    }

    private void createComboBox() {
        Label holidayOrg = new Label("��� ���������:");
        holidayOrg.setFont(font);
        root.add(holidayOrg, 0, 0);
        kindEdit = new ComboBox<>();
        kindEdit.setStyle("-fx-font-size: 24 pt");
        kindEdit.getItems().addAll(
                "������",
                "�����",
                "������",
                "�����"
        );
        kindEdit.setValue(pet.getKind());
        root.add(kindEdit, 1, 0);
    }

    private void createSpinner() {
        Label year = new Label("���������� ���:");
        year.setFont(font);
        root.add(year, 0, 3);
        yearEdit = new Spinner<>(0, 100, pet.getYear(),1);
        yearEdit.setStyle("-fx-font-size: 24 pt");
        yearEdit.setEditable(true);
        root.add(yearEdit, 1, 3);

        Label month = new Label("���������� �������:");
        month.setFont(font);
        root.add(month, 0, 4);
        monthEdit = new Spinner<>(0, 11, pet.getMonth(), 1);
        monthEdit.setStyle("-fx-font-size: 24 pt");
        monthEdit.setEditable(true);
        root.add(monthEdit, 1, 4);

    }

    private void createButtons() {
        Button btnOk = new Button("Ok");
        btnOk.setFont(Font.font(24));
        root.add(btnOk, 0, 5);
        btnOk.setOnAction((ActionEvent e) -> {
            if (isInputMaster())
                handleOk();
            else {
                if (isInputName()  )
                    handleOk();
                else message();
            }
        });
        Button btnCancel = new Button("Cancel");
        btnCancel.setFont(Font.font(24));
        root.add(btnCancel, 1, 5);
        btnCancel.setOnAction((ActionEvent e) -> {
            handleCancel();
        });
    }

    private void message(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("�������� ����");
        alert.setHeaderText(null);
        alert.setContentText("��� ������� �� � ������� �����");
        alert.showAndWait();
    }

    public PetEditDialog(Pet pet) {
        this.pet = pet;
        dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("������� ���������� � ��������");
        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10);
        root.setVgap(10);
        font = Font.font("Tahoma", FontWeight.NORMAL, 20);
        createNameText();
        createSpinner();
        createComboBox();
        createMasterText();
        createButtons();
        Scene scene = new Scene(root, 600, 500);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private boolean isInputName() {
        String str[]=nameEdit.getText().split("");
        return str[0].matches("[A-Z�-�]");
    }

    private boolean isInputMaster() {
        String str[]=nameMasterEdit.getText().split("");
        return str[0].matches("[A-Z�-�]");
    }

    private void handleOk() {
        pet.setName(nameEdit.getText());
        pet.setHost_name(nameMasterEdit.getText());
        pet.setKind(kindEdit.getValue());
        pet.setYear(yearEdit.getValue());
        pet.setMonth(monthEdit.getValue());
        result = ButtonType.OK;
        dialog.close();
    }

    private void handleCancel() {
        result = ButtonType.CANCEL;
        dialog.close();
    }

    public ButtonType getResult() {
        return result;
    }

}
