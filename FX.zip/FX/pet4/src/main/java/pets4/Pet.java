package pets4;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Pet {

    private StringProperty kind;
    private StringProperty name;
    private IntegerProperty year;
    private IntegerProperty month;
    private StringProperty host_name;

    public StringProperty kindStringProprty(){
        if (kind==null){
            kind= new SimpleStringProperty();
        }
        return kind;
    }
    public final void setKind(String value){
        kindStringProprty().set(value);
    }

    public final String getKind() {
        return kindStringProprty().get();
    }



    public StringProperty nameStringProperty() {
        if (name == null) {
            name = new SimpleStringProperty();
        }
        return name;
    }

    public final void setName(String value) {
        nameStringProperty().set(value);
    }

    public final String getName() {
        return nameStringProperty().get();
    }


    public IntegerProperty yearIntegerProperty() {
        if (year == null) {
            year = new SimpleIntegerProperty();
        }
        return year;
    }

    public final void setYear(int value) {
        yearIntegerProperty().set(value);
    }

    public final int getYear() {
        return yearIntegerProperty().get();
    }


    public IntegerProperty monthIntegerProperty() {
        if (month == null) {
            month = new SimpleIntegerProperty();
        }
        return month;
    }

    public final void setMonth(int value) {

        monthIntegerProperty().set(value);
    }

    public final int getMonth() {
        return monthIntegerProperty().get();
    }



    public StringProperty  host_nameStringProprty(){
        if ( host_name==null){
            host_name= new SimpleStringProperty();
        }
        return  host_name;
    }
    public final void setHost_name(String value){
        host_nameStringProprty().set(value);
    }

    public final String getHost_name() {
        return  host_nameStringProprty().get();
    }


    public Pet(String kind, String name, int year, int month, String host_name){
        setKind(kind);
        setName(name);
        setYear(year);
        setMonth(month);
        setHost_name(host_name);

    }
    public Pet(){return;}

}