package pets12;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main  extends Application {

    private ObservableList<Pet> data
            = FXCollections.observableArrayList(
            new Pet ("Cow", "Toyota", 1, 9, "Gonobobka"),
            new Pet ("Hamster", "Bead", 2,3, "Veronica")
    );

    @Override
    public void start(Stage primaryStage) {
        try {
            primaryStage.setTitle("Pets");

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("MainWindow.fxml"));
            Parent root = loader.load();
            MainWindowController controller = loader.getController();
            controller.setData(data);

            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();
        }catch (Exception e){
            System.out.println("Loader error");

        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
