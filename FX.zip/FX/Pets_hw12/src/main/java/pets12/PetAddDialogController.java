package pets12;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PetAddDialogController {
    @FXML
    private TextField addKind;
    @FXML
    private TextField addName;
    @FXML
    private TextField addHost_name;
    @FXML
    private TextField addYear;
    @FXML
    private TextField addMonth;
    private Stage dialogStage;
    private Pet pet;
    private ButtonType result = ButtonType.CANCEL;
    String errorMessage = "";


    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    public void setPet(Pet pet) {
        this.pet = pet;
    }
    public ButtonType getResult() {
        return result;
    }
    private boolean isInputValid() {
        if (addKind.getText() == null || addKind.getText().length() == 0) {
            errorMessage += "No valid species! ";
        }
        if (addName.getText() == null || addName.getText().length() == 0) {
            errorMessage += "No valid pet name! ";
        }
        if (addHost_name.getText() == null || addHost_name.getText().length() == 0) {
            errorMessage += "No valid owner name! ";
        }
        if (addYear.getText() == null || addYear.getText().length() == 0) {
            errorMessage += "No valid years! ";
        }
        else {
            try {
                if (addMonth.getText() == null || addMonth.getText().length() == 0 ||
                        Integer.parseInt(addMonth.getText()) >= 12){
                    errorMessage += Integer.parseInt(addYear.getText());
                }
                Integer.parseInt(addYear.getText());
                Integer.parseInt(addMonth.getText());
            }
            catch (NumberFormatException e) {
                errorMessage += "No valid age (must be an integer)! ";
            }
        }
        if (errorMessage.length() == 0)
            return true;
        else
            return false;
    }
    @FXML
    private void handleOk() {
        if (isInputValid()) {
            pet.setKind(addKind.getText());
            pet.setName(addName.getText());
            pet.setHost_name(addHost_name.getText());
            pet.setYear(Integer.parseInt(addYear.getText()));
            pet.setMonth(Integer.parseInt(addMonth.getText()));
            result = ButtonType.OK;
            dialogStage.close();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage);
            DialogPane dialogPane = alert.getDialogPane();
            dialogPane.getStylesheets().add(getClass().getResource("alertstyle.css").toExternalForm());
            errorMessage="";
            alert.showAndWait();
        }
    }
    @FXML
    private void handleCancel() {
        result = ButtonType.CANCEL;
        dialogStage.close();
    }

}
