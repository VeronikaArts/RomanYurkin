package pets1;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ViewPet {
    private Hamster hamster;
    private GridPane grid;
    private Text kindHamster; //���
    private Text nameHamster; //���
    private Text  yearHamster;
    private Text monthHamster;
    private Text nameVeroniki;


    private void createPane(){
        grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Label kind = new Label("���: ");
        kind.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(kind, 0, 0);

        kindHamster = new Text();
        kindHamster.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(kindHamster, 1, 0);

        Label nameH = new Label("��� �������: ");
        nameH.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(nameH, 0, 1);

        nameHamster = new Text();
        nameHamster.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(nameHamster, 1, 1);

        Label year = new Label("�������: ");
        year.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(year, 0, 3);

        yearHamster = new Text();
        yearHamster.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(yearHamster, 1, 3);

        monthHamster = new Text();
        monthHamster.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(monthHamster, 2, 3);


        Label Veronika = new Label("��� �������: ");
        Veronika.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(Veronika, 0, 4);

        nameVeroniki = new Text();
        nameVeroniki.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(nameVeroniki, 1, 4);


    }

    public GridPane getPane() {
        return grid;
    }

    public void setHamster(Hamster hamster){
        this.hamster = hamster;
        setInform();
    }
    public void setInform(){
        kindHamster.setText(hamster.getKind());
        nameHamster.setText(hamster.getName());
        //���������� �������� �� ���������� ������ ��� �� ������� ���: "5 ����"
        yearHamster.setText(Integer.toString(hamster.getYear())+" year(s)");
        monthHamster.setText(Integer.toString(hamster.getMonth())+" �����(��)");
        nameVeroniki.setText(hamster.getHost_name());

    }

    public ViewPet(Hamster ham){
        createPane();
        setHamster(ham);

    }

}



