package pets1;

public class Hamster {

    private String kind;
    private String name;

    private int year;
    private int month;

    private String host_name;

    public Hamster(String kind, String name, int year, int month, String host_name){
        this.kind=kind;
        this.name=name;
        this.year=year;
        this.month=month;
        this.host_name=host_name;

    }

    public String getKind() {
        return kind;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public String getHost_name() {
        return host_name;
    }

    public void The_hamster_is_growing(){
        if (this.month<11 && this.month>=0){

            this.month++;
        }
        else {
            this.year++;
            this.month=0;
        }


    }

}
