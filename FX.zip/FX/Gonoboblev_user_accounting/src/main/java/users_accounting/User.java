package users_accounting;

import javafx.beans.property.*;

public class User {

    private StringProperty login;
    private StringProperty password;
    private StringProperty name;
    private StringProperty surname;
    private StringProperty email;

    public StringProperty loginStringProprty(){
        if (login ==null){
            login = new SimpleStringProperty();
        }
        return login;
    }
    public final void setLogin(String value){
        loginStringProprty().set(value);
    }
    public final String getLogin() {
        return loginStringProprty().get();
    }

    public StringProperty passwordStringProperty() {
        if (password == null) {
            password = new SimpleStringProperty();
        }
        return password;
    }
    public final void setPassword(String value) {
        passwordStringProperty().set(value);
    }
    public final String getPassword() {
        return passwordStringProperty().get();
    }

    public StringProperty  nameStringProprty(){
        if ( name ==null){
            name = new SimpleStringProperty();
        }
        return name;
    }
    public final void setName(String value){
        nameStringProprty().set(value);
    }
    public final String getName() {
        return  nameStringProprty().get();
    }

    public StringProperty surnameStringProprty(){
        if (surname ==null){
            surname = new SimpleStringProperty();
        }
        return surname;
    }
    public final void setSurname(String value){
        surnameStringProprty().set(value);
    }
    public final String getSurname() {
        return surnameStringProprty().get();
    }

    public StringProperty emailStringProprty(){
        if (email ==null){
            email = new SimpleStringProperty();
        }
        return email;
    }
    public final void setEmail(String value){
        emailStringProprty().set(value);
    }
    public final String getEmail() {
        return emailStringProprty().get();
    }

    public String toString(){
        return login.toString()+" "+password.toString();
    }

    public User(String login, String password, String email, String surname ,String name){
        loginStringProprty().set(login);
        passwordStringProperty().set(password);
        emailStringProprty().set(email);
        surnameStringProprty().set(surname);
        nameStringProprty().set(name);
    }

    @Override
    public boolean equals(Object Obj) {
        if (Obj == null)
            return false;
        if (this != Obj)
            return true;
        if (!(Obj instanceof User))
            return false;
        User E = (User) Obj;

            if ((password.toString() == E.getPassword().toString()) && login.toString() == E.getLogin().toString() ) {
                return false;
            } else return true;
    }


    public User(){return;}

}