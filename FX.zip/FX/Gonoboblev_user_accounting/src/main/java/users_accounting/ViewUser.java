package users_accounting;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ViewUser {
    private User user;
    private GridPane grid;
    private Text Name;
    private Text Surname;
    private Text Email;


    private void createPane(){
        grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Label name= new Label("Name: ");
        name.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(name, 0, 0);

        Name = new Text();
        Name.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(Name, 1, 0);

        Label surname = new Label("Surname: ");
        surname.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(surname, 0, 1);

        Surname = new Text();
        Surname.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(Surname, 1, 1);

        Label email = new Label("Email: ");
        email.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(email, 0, 2);

        Email = new Text();
        Email.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(Email, 1, 2);

    }

    public GridPane getPane() {
        return grid;
    }

    public void setUser(User user){
        this.user = user;
        Name.textProperty().bind(this.user.nameStringProprty());
        Surname.textProperty().bind(this.user.surnameStringProprty());
        Email.textProperty().bind(this.user.emailStringProprty());
    }

    public ViewUser(User user){
        createPane();
        setUser(user);

    }

}
