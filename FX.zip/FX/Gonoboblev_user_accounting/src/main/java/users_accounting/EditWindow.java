package users_accounting;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EditWindow {
    private User user;
    private Stage dialog;
    private TextField nameEdit;
    private TextField surnameEdit;
    private TextField passwordEdit;
    private TextField loginEdit;
    private TextField emailEdit;

    private Font font;
    private GridPane root;
    private ButtonType result = ButtonType.CANCEL;

    private void createLoginText() {
        Label login = new Label("Login:");
        login.setFont(font);
        root.add(login, 0, 1);
        loginEdit = new TextField();
        loginEdit.setFont(Font.font(24));
        loginEdit.setText(user.getLogin());
        root.add(loginEdit, 1, 1);
    }

    private void createPasswordText() {
        Label password = new Label("Password:");
        password.setFont(font);
        root.add(password, 0, 2);
        passwordEdit= new TextField();
        passwordEdit.setFont(Font.font(24));
        passwordEdit.setText(user.getPassword());
        root.add(passwordEdit, 1, 2);
    }

    private void createNameText() {
        Label password = new Label("Name:");
        password.setFont(font);
        root.add(password, 0, 3);
        nameEdit= new TextField();
        nameEdit.setFont(Font.font(24));
        nameEdit.setText(user.getPassword());
        root.add(nameEdit, 1, 3);
    }

    private void createSurnameText() {
        Label password = new Label("Surname:");
        password.setFont(font);
        root.add(password, 0, 4);
        surnameEdit= new TextField();
        surnameEdit.setFont(Font.font(24));
        surnameEdit.setText(user.getPassword());
        root.add(surnameEdit, 1, 4);
    }
    private void createEmailText() {
        Label password = new Label("Email:");
        password.setFont(font);
        root.add(password, 0, 5);
        emailEdit= new TextField();
        emailEdit.setFont(Font.font(24));
        emailEdit.setText(user.getPassword());
        root.add(emailEdit, 1, 5);
    }


    private void createButtons() {
        Button btnOk = new Button("Ok");
        btnOk.setFont(Font.font(24));
        root.add(btnOk, 0, 6);
        btnOk.setOnAction((ActionEvent e) -> {
            if (isInputLogin() && isInputEmail())
                handleOk();
            else message();
        });
        Button btnCancel = new Button("Cancel");
        btnCancel.setFont(Font.font(24));
        root.add(btnCancel, 1, 6);
        btnCancel.setOnAction((ActionEvent e) -> {
            handleCancel();
        });
    }

    private void message(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid input");
        alert.setHeaderText(null);
        alert.setContentText("Invalid input");
        alert.showAndWait();
    }

    public EditWindow(User user) {
        this.user=user;
        dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Edit data");
        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10);
        root.setVgap(10);
        font = Font.font("Tahoma", FontWeight.NORMAL, 20);
        createLoginText();
        createPasswordText();
        createEmailText();
        createNameText();
        createSurnameText();
        createButtons();
        Scene scene = new Scene(root, 600, 500);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private boolean isInputLogin() {
        return loginEdit.getText().matches("[A-Z]*[1-9]*[a-z]+[A-Z]*[1-9]*");
    }

    private boolean isInputEmail() {
        return emailEdit.getText().matches("[a-zA-Za-z]+[a-zA-Za-z]*[1-9]*[@][a-z]+[.][a-z]+");
    }

    private void handleOk() {
        user.setLogin(loginEdit.getText());
        user.setPassword(passwordEdit.getText());
        user.setEmail(emailEdit.getText());
        user.setName(nameEdit.getText());
        user.setSurname(surnameEdit.getText());
        result = ButtonType.OK;
        dialog.close();
    }

    private void handleCancel() {
        result = ButtonType.CANCEL;
        dialog.close();
    }

    public ButtonType getResult() {
        return result;
    }


}
