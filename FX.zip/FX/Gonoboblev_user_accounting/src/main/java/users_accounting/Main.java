package users_accounting;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.*;
import java.util.Optional;


public class Main  extends Application {

    VBox vbox;
    private User mainUser =new User("","","","","");
    private String errorMessage="";
    BorderPane root = new BorderPane();

    private ObservableList<User> data= FXCollections.observableArrayList();

    private void showMessage(String message){
        Alert mess = new Alert(Alert.AlertType.WARNING,message,ButtonType.OK);
        mess.showAndWait();
    }

    private void readDataFromFile(File dataFile) {
        try {
            data.clear();
            errorMessage="";
            BufferedReader in = new BufferedReader(new FileReader(dataFile));
            String str;
            while ((str = in.readLine()) != null) {
                try {
                    if(str.isEmpty()) break;
                    String[] dataArray = str.split(" +");
                    if (dataArray.length != 4)
                        throw new Exception("Wrong data");
                    String login = dataArray[0];
                    String name = dataArray[1];
                    String surname = dataArray[2];
                    String email=dataArray[3];
                    String password= in.readLine();
                    if (password== null || password.isEmpty())
                        throw new Exception("wrong");
                   User user=new User(login,password,email,surname,name);
                    data.add(user);
                } catch (Exception e){
                    errorMessage+=e.getMessage()+"\n";
                    in.close();
                }
            }
            in.close();
        } catch (IOException e){
            errorMessage+=e.getMessage()+"\n";
        }
    }

    @Override
    public void init() {
        readDataFromFile(new File("src/main/java/users_accounting/data.txt"));
    }

    private boolean passwordComplexity(String password){
        String[] str=password.split("");
        boolean flag=false;
        if(str.length>5)
            flag=true;
        return flag;
    }

    private void handleButtonAdd(User user) {
        NewAccount newAccount=new NewAccount(user);
        if (newAccount.getResult() == ButtonType.OK) {
            if(passwordComplexity(user.getPassword()) && !haveLogin(user.getLogin()) ){
                data.add(user);
            }else {
                if( haveLogin(user.getLogin()) ){

                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Existing login");
                    alert.setHeaderText(null);
                    alert.setContentText("The login you entered already exists.\nCome up with another one.");
                    alert.getDialogPane().setMinSize(200, 200);
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.get() == ButtonType.OK)
                        handleButtonAdd(user);
                    else handleButtonAut(1);
                }else {
                    if(!passwordComplexity(user.getPassword())) {
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle("Password is not complex enough");
                        alert.setHeaderText(null);
                        alert.setContentText("The password is not complex enough.\nCome up with a more complex password.");
                        alert.getDialogPane().setMinSize(200, 200);
                        Optional<ButtonType> result = alert.showAndWait();
                        if (result.get() == ButtonType.OK)
                            handleButtonAdd(user);
                        else handleButtonAut(1);
                    }
                }
            }
        }
    }

    private boolean haveLogin(String log){
        boolean flag=false;
        for (int i=0; i<data.size(); i++){
            if (data.get(i).getLogin().equals(log)) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    private Menu createMenu() {
        Menu fileMenu = new Menu("Menu");
        MenuItem open = new MenuItem("Logout");
        MenuItem exit = new MenuItem("Exit");
        fileMenu.getItems().addAll(open, new SeparatorMenuItem(), exit);
        open.setOnAction((ActionEvent event) -> handleButtonAut(1));
        exit.setOnAction((ActionEvent event) ->Platform.exit());
        return fileMenu;
    }

    private Menu createEdit(User user) {
        Menu Menu = new Menu("Edit");
        MenuItem edit = new MenuItem("Edit inform");
        Menu.getItems().addAll(edit);
        edit.setOnAction((ActionEvent event) -> handleButtonEdit(user));
        return Menu;
    }

    private void handleButtonEdit(User user) {
        if (user != null) {
            EditWindow editWindow = new EditWindow(user);
        }
    }

    private  void createSceneElements(User user){
        ViewUser viewUser=new ViewUser(user);
        vbox=new VBox();
        vbox.getChildren().add(viewUser.getPane());
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(20);
        vbox.setPadding(new Insets(10));
    }

    private void createMainWindow(User user){
        createSceneElements(user);
        MenuBar menuBar=new MenuBar();
        menuBar.getMenus().addAll(createMenu(),createEdit(user));
        root.setTop(menuBar);
        root.setCenter(vbox);
    }

    private int handleButtonAut(int number_of_attempts) {
        HBox root1= new HBox(10);
        root1.getChildren().add(new Separator(Orientation.VERTICAL));
        User p= new User("","","","","");
        AuthorizationWindow aut=new AuthorizationWindow(p);
        if (aut.getResult() == ButtonType.OK ){
            if(chekLogin(p.getLogin()) && chekPassword(p.getPassword())){
                createSceneElements(mainUser);
                createMainWindow(mainUser);
            }else {
                if (chekLogin(p.getLogin()) && !chekPassword(p.getPassword())){
                    if (number_of_attempts<4) {
                        number_of_attempts++;
                        messagePassword(number_of_attempts);
                        handleButtonAut(number_of_attempts);
                    }else {
                        number_of_attempts=messagePasswordEnd();
                        handleButtonAut(number_of_attempts);
                    }
                }else {
                    notExist(p);
                    createSceneElements(p);
                    createMainWindow(p);
                }
            }
            return number_of_attempts;
        }else {
            createSceneElements(p);
            createMainWindow(p);
            return number_of_attempts;
        }
    }

    private void messagePassword(int number_of_attempts){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid password");
        alert.setHeaderText(null);
        alert.setContentText("Invalid password\nRemaining "+(5-number_of_attempts)+ " attempts");
        alert.showAndWait();
    }

    private int messagePasswordEnd(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("End");
        alert.setHeaderText(null);
        alert.setContentText("This is your authority.\n" +
                "You can try to log in with a different username\n" +
                "and not be mistaken with the password;)");
        alert.showAndWait();
        return 1;
    }

    private boolean chekPassword( String password){
        boolean flag=false;
            for (int i=0; i<data.size(); i++) {
                if (password.equals(data.get(i).getPassword())) {
                    flag = true;
                    mainUser = data.get(i);
                    break;
                }
            }
        return flag;
    }

    private boolean chekLogin(String login){
        boolean flag=false;
        for (int i=0; i<data.size(); i++){
            if (login.equals(data.get(i).getLogin())) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    private void notExist(User user) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("User is not registered");
        alert.setHeaderText(null);
        alert.setContentText("Would you like to create an account with the login �"+user.getLogin()+"�?");
        alert.getDialogPane().setMinSize(200, 200);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            handleButtonAdd(user);
        } else {
            handleButtonAut(1);
        }
    }

    @Override
    public void start(Stage primaryStage) {
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
        primaryStage.setTitle("User");
        int number_of_attempts=1;

        handleButtonAut(number_of_attempts);
        Scene scene = new Scene(root,400, 400);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public static void main(String[] args) {
        launch(args);
    }

}
