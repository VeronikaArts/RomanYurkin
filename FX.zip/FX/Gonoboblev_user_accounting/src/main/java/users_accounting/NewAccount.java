package users_accounting;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class NewAccount {
    private User user;
    private Stage dialog;
    private TextField loginEdit;
    private TextField passwordEdit;
    private TextField password2Edit;

    private Font font;
    private GridPane root;
    private ButtonType result = ButtonType.CANCEL;

    private void createLoginText() {
        Label log = new Label("Login:");
        log.setFont(font);
        root.add(log, 0, 1);
        loginEdit = new TextField();
        loginEdit.setFont(Font.font(24));
        loginEdit.setText(user.getLogin());
        root.add(loginEdit, 1, 1);
    }

    private void createPasswordText() {
        Label pas = new Label("Password:");
        pas.setFont(font);
        root.add(pas, 0, 2);
        passwordEdit= new TextField();
        passwordEdit.setFont(Font.font(24));
        passwordEdit.setText(user.getPassword());
        root.add(passwordEdit, 1, 2);
    }
    private void createPasswordDoudleText() {
        Label Master = new Label("Repeat password:");
        Master.setFont(font);
        root.add(Master, 0, 3);
        password2Edit= new TextField();
        password2Edit.setFont(Font.font(24));
        password2Edit.setText(user.getPassword());
        root.add(password2Edit, 1, 3);
    }


    private void createButtons() {
        Button btnOk = new Button("Create");
        btnOk.setFont(Font.font(24));
        root.add(btnOk, 0, 4);
        btnOk.setOnAction((ActionEvent e) -> {
            if (isInputLogin() && isInputPassword() && isInput2Password()){
                if (isPasswordCompare())
                    handleOk();
                else messagePass();
            }else message();
        });
        Button btnCancel = new Button("Cancel");
        btnCancel.setFont(Font.font(24));
        root.add(btnCancel, 1, 4);
        btnCancel.setOnAction((ActionEvent e) -> {
            handleCancel();
        });
    }

    private void message(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid input");
        alert.setHeaderText(null);
        alert.setContentText("Invalid input");
        alert.showAndWait();
    }

    private void messagePass(){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Password mismatch");
        alert.setHeaderText(null);
        alert.setContentText("Password mismatch");
        alert.showAndWait();
    }

    public NewAccount (User user) {
        this.user=user;
        dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("New account");
        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10);
        root.setVgap(10);
        font = Font.font("Tahoma", FontWeight.NORMAL, 20);
        createLoginText();
        createPasswordText();
        createPasswordDoudleText();
        createButtons();

        Scene scene = new Scene(root, 600, 500);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private boolean isInputLogin() {
        return loginEdit.getText().matches("[A-Z]*[1-9]*[a-z]+[A-Z]*[1-9]*");
    }

    private boolean isInputPassword() {
        return passwordEdit.getText().matches("[A-Z]*[1-9]*[a-z]+[A-Z]*[1-9]*");
    }
    private boolean isInput2Password() {
        return password2Edit.getText().matches("[A-Z]*[1-9]*[a-z]+[A-Z]*[1-9]*");
    }
    private boolean isPasswordCompare() {
        return passwordEdit.getText().equals(password2Edit.getText());
    }

    private void handleOk() {
        user.setLogin(loginEdit.getText());
        user.setPassword(passwordEdit.getText());
        result = ButtonType.OK;
        dialog.close();
    }

    private void handleCancel() {
        result = ButtonType.CANCEL;
        dialog.close();
    }

    public ButtonType getResult() {
        return result;
    }
}
