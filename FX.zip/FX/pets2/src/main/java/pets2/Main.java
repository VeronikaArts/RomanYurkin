package pets2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("�������");
        Pet pet = new Pet("�����", "�������", 1, 9, "��������");

        HBox root= new HBox(10);

        ViewPet veiew_pet = new ViewPet(pet);

        root.getChildren().add(veiew_pet.getPane());
        root.getChildren().add(new Separator(Orientation.VERTICAL));
        root.getChildren().add(editBlock(pet));

        Scene scene = new Scene(root,600,550);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox editBlock(Pet pet){
        VBox editPane = new VBox(20);
        editPane.setPadding(new Insets(20));

        Label labelKind = new Label("������� ��� �������");
        labelKind.setFont(Font.font(15));

        TextField editKind = new TextField();
        editKind.setFont(Font.font(10));
        editKind.setPrefSize(50,30);

        Label labelName = new Label("������� ��� �������");
        labelName.setFont(Font.font(15));

        TextField editName = new TextField();
        editName.setFont(Font.font(10));
        editName.setPrefSize(50,30);

        Label labelMaster = new Label("������� ��� ������� �������");
        labelMaster.setFont(Font.font(15));

        TextField editMaster = new TextField();
        editMaster.setFont(Font.font(10));
        editMaster.setPrefSize(50,30);

        Label labelAge = new Label("������� ������� �������");
        labelAge.setFont(Font.font(15));

        Label labelYear = new Label("���������� ���");
        labelYear.setFont(Font.font(15));

        Spinner<Integer> editYear = new Spinner<>(0, 100, 0, 1);
        editYear.setPrefSize(50, 30);
        editYear.setStyle("-fx-font-size: 10");

        Label labelMonth = new Label("���������� �������");
        labelMonth.setFont(Font.font(15));

        Spinner<Integer> editMonth = new Spinner<>(0, 11, 0, 1);
        editMonth.setPrefSize(50, 30);
        editMonth.setStyle("-fx-font-size: 10");

        Button btn = new Button("Edit");
        btn.setFont(Font.font(10));
        btn.setOnAction((ActionEvent event) -> {
            pet.setKind(editKind.getText());
            pet.setName(editName.getText());
            pet.setHost_name(editMaster.getText());
            pet.setYear(editYear.getValue());
            pet.setMonth(editMonth.getValue());
        });

        editPane.getChildren().addAll(labelKind, editKind , labelName, editName, labelMaster,editMaster ,
                labelAge,labelYear,
                editYear, labelMonth,editMonth,btn);
        return editPane;

    }

    public static void main(String[] args) {
        launch(args);
    }

}

