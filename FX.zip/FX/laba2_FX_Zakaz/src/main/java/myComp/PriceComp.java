package myComp;

import product.Product;

import java.util.Comparator;

public class PriceComp implements Comparator<Product> {
    @Override
    public int compare(Product K, Product T){
        if(K.getPrice()>T.getPrice())
            return 1;
        else {
            if(K.getPrice()==T.getPrice())
                return 0;
            else return -1;
        }


    }
}
