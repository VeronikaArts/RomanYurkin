package myComp;

import product.Product;

import java.util.Comparator;


public class NameProdComp implements Comparator<Product>{

    @Override
    public int compare(Product K, Product T){

        return K.getName_product().compareTo(T.getName_product());

    }
}
