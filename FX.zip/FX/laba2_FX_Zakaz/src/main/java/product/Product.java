package product;

import javafx.beans.property.*;

public class Product {

    private StringProperty name_product;
    private StringProperty name_generator;
    private SimpleDoubleProperty price;
    private StringProperty specification;

    public StringProperty name_productStringProprty(){
        if (name_product==null){
            name_product= new SimpleStringProperty();
        }
        return name_product;
    }
    public final void setName_product(String value){
        name_productStringProprty().set(value);
    }
    public final String getName_product() {
        return name_productStringProprty().get();
    }

    public StringProperty name_generatorStringProperty() {
        if (name_generator== null) {
            name_generator = new SimpleStringProperty();
        }
        return name_generator;
    }
    public final void setName_generator(String value) {
        name_generatorStringProperty().set(value);
    }
    public final String getName_generator() {
        return name_generatorStringProperty().get();
    }

    public DoubleProperty priceDoubleProperty() {
        if (price == null) {
            price= new SimpleDoubleProperty();
        }
        return price;
    }
    public final void setPrice(Double value) { priceDoubleProperty().set(value); }
    public final double getPrice() {
        return priceDoubleProperty().get();
    }

    public StringProperty  specificationStringProprty(){
        if ( specification==null){
            specification= new SimpleStringProperty();
        }
        return  specification;
    }
    public final void setSpecification(String value){
        specificationStringProprty().set(value);
    }
    public final String getSpecification() {
        return  specificationStringProprty().get();
    }

    public  boolean isName_Generator(Product p){
        return name_generator.toString().equals(p.name_generator.toString());
    }

    public String toString(){
        return name_product.toString()+" " +name_generator.toString()+" "+price.toString()+" "+specification.toString();
    }

    public Product(String name_product, String name_generator, double price, String specification){
        name_productStringProprty().set(name_product);
        name_generatorStringProperty().set(name_generator);
        priceDoubleProperty().set(price);
        specificationStringProprty().set(specification);
    }
    public Product(){return;}

}