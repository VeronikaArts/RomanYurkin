package product;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import myComp.PriceComp;
import myComp.NameProdComp;

import java.io.*;


public class Main  extends Application {

    private TableView<Product> table = new TableView<>();
    private TableView<Product> tableZakaz = new TableView<>();
    private String errorMessage="";

    private ObservableList<Product> data= FXCollections.observableArrayList();
    private ObservableList<Product> dataZakaz= FXCollections.observableArrayList(new Product("In total:","",0,""));

    private void showMessage(String message){
        Alert mess = new Alert(Alert.AlertType.WARNING,message,ButtonType.OK);
        mess.showAndWait();
    }

    private void handleFileOpen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open file to read data");
        File file = fileChooser.showOpenDialog(null);
        if (file == null) {
            return;
        }
        readDataFromFile(file);
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
    }

    private void handleFileSave() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save order to file");
        File file = fileChooser.showSaveDialog(null);
        if (file == null) {
            return;
        }
        saveDataToFile(file);
    }

    private void readDataFromFile(File dataFile) {

        try {
            data.clear();
            errorMessage="";
            BufferedReader in = new BufferedReader(new FileReader(dataFile));
            String str;
            while ((str = in.readLine()) != null) {
                try {
                    if(str.isEmpty()) break;
                    String[] dataArray = str.split(" +");
                    if (dataArray.length != 3)
                        throw new Exception("Wrong data");
                    String name_prod = dataArray[0];
                    String name_gen = dataArray[1];
                    double price = Double.parseDouble(dataArray[2]);
                    String spe = in.readLine();
                    if (spe == null || spe.isEmpty())
                        throw new Exception("wrong");
                    Product prod= new Product(name_prod,name_gen,price,spe);
                    data.add(prod);


                } catch (Exception e){
                    errorMessage+=e.getMessage()+"\n";
                    in.close();
                }
            }

            in.close();
        } catch (IOException e){
            errorMessage+=e.getMessage()+"\n";
        }

        NameProdComp compNameP= new NameProdComp();
        PriceComp priceComp = new PriceComp();
        data.sort(compNameP.thenComparing(priceComp).thenComparing((K, T)->(K.getName_generator().compareTo(T.getName_generator()))));
        sort(data.size());
        sort(data.size());

    }

    public void sort(int max){
        int i=1;
        while (i<max){
            if(data.get(i).getName_product().equals(data.get(i-1).getName_product())){
                if(data.get(i).getName_generator().equals(data.get(i-1).getName_generator())){
                    if(data.get(i).getPrice()==data.get(i-1).getPrice()){
                        data.remove(i);
                        max--;
                    }
                }
            }
            i++;
        }
    }

    @Override
    public void init() {
        readDataFromFile(new File("src/main/java/product/product.txt"));
    }


    private void saveDataToFile(File dataFile) {
        try {
            FileWriter out = new FileWriter(dataFile);
            for (Product prod : dataZakaz) {
                out.write( prod.getName_product()+" "+prod.getPrice()+"\n");
            }
            out.close();
        } catch (IOException e){
            showMessage(e.getMessage());
        }
    }

    private void createTable() {
        TableColumn name1 = new TableColumn("Product name");
        name1.setMinWidth(150);
        name1.setCellValueFactory(new PropertyValueFactory<Product, String>("name_product"));
        name1.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn name2 = new TableColumn("Manufacturer's name");
        name2.setMinWidth(180);
        name2.setCellValueFactory(new PropertyValueFactory<Product, String>("name_generator"));
        name2.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn price = new TableColumn("Price");
        price.setMinWidth(120);
        price.setCellValueFactory(new PropertyValueFactory<Product, Double>("price"));
        price.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));

        TableColumn spec = new TableColumn("Product description");
        spec.setMinWidth(250);
        spec.setCellValueFactory(new PropertyValueFactory<Product, String>("specification"));
        spec.setCellFactory(TextFieldTableCell.forTableColumn());

        table.setItems((ObservableList<Product>) data);
        table.getColumns().addAll(name1,name2,price,spec);
        table.setMaxSize(820,400);
    }

    private void createTableZakaz() {
        TableColumn name1 = new TableColumn("Product");
        name1.setMinWidth(150);
        name1.setCellValueFactory(new PropertyValueFactory<Product, String>("name_product"));
        name1.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn price = new TableColumn("Price");
        price.setMinWidth(120);
        price.setCellValueFactory(new PropertyValueFactory<Product, Double>("price"));
        price.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));

        tableZakaz.setItems(dataZakaz);
        tableZakaz.getColumns().addAll(name1,price);
        tableZakaz.setMaxSize(820,400);
    }

    private void handleButtonEdit() {
        Product p = table.getSelectionModel().getSelectedItem();
        if (p != null) {
            ProductEditDialog pEditDialog = new ProductEditDialog(p,"Edit product information");
            table.refresh();
        } else {
            showMessage("Item not selected");
        }
    }

    private void handleButtonAdd() {
        Product p= new Product("", "", 0.1,"");
        ProductEditDialog petEdit=new ProductEditDialog(p,"Adding a product");
        if (petEdit.getResult() == ButtonType.OK) {
            data.add(p);
        }
    }

    private void handleButtonDelete() {
        int selectedIndex = table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            table.getItems().remove(selectedIndex);
        } else {
            showMessage("Unable to delete item");
        }
    }

    private Menu createFileMenu() {
        Menu fileMenu = new Menu("File");
        MenuItem open = new MenuItem("Open");
        MenuItem exit = new MenuItem("Exit");
        fileMenu.getItems().addAll(open, new SeparatorMenuItem(), exit);
        open.setOnAction((ActionEvent event) -> handleFileOpen());
        exit.setOnAction((ActionEvent event) ->Platform.exit());
        return fileMenu;
    }

    private Menu createEditMenu() {
        Menu editMenu = new Menu("Edit");

        MenuItem add = new MenuItem("Add product");
        editMenu.getItems().add(add);
        add.setOnAction((ActionEvent event) -> handleButtonAdd());

        MenuItem edit = new MenuItem("Edit product information");
        editMenu.getItems().add(edit);
        edit.setOnAction((ActionEvent event) -> handleButtonEdit());

        MenuItem delete = new MenuItem("Delete product");
        editMenu.getItems().add(delete);
        delete.setOnAction((ActionEvent event) -> handleButtonDelete());

        return editMenu;
    }

    private Menu createShowSortMenu() {
        Menu showMenu = new Menu("Forming an order");
        MenuItem addProduct = new MenuItem("Add product to order");

        addProduct.setOnAction((ActionEvent e) -> {
            Product p = table.getSelectionModel().getSelectedItem();
            if (p != null) {
               dataZakaz.add(0,p);
               double sum= dataZakaz.get(0).getPrice()+dataZakaz.get(dataZakaz.size()-1).getPrice();
               dataZakaz.get(dataZakaz.size()-1).setPrice(sum);
            } else {
                showMessage("Product not selected");
            }
        });

        MenuItem newZakaz = new MenuItem("New order");

        newZakaz.setOnAction((ActionEvent e) -> {
            dataZakaz.clear();
            dataZakaz.add(new Product("In total:","",0,""));
        });

        MenuItem saveZakaz = new MenuItem("Save order");
        saveZakaz.setOnAction((ActionEvent event) -> handleFileSave());

        showMenu.getItems().addAll(addProduct,newZakaz,saveZakaz);
        return showMenu;
    }



    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
        primaryStage.setTitle("Product");

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));

        createTable();
        createTableZakaz();

        table.setItems((ObservableList<Product>) data);
        table.setPadding(new Insets(10));
        root.setLeft(table);

        root.setRight(tableZakaz);

        root.setTop(new MenuBar(createFileMenu(), createEditMenu(),createShowSortMenu()));


        Scene scene = new Scene(root,1050, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
