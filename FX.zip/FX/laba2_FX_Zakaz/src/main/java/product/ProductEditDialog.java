package product;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ProductEditDialog {
    private Product pr;
    private Stage dialog;
    private TextField name_prEdit;
    private TextField name_genEdit;
    private Spinner<Double> priceEdit;
    private TextField speEdit;

    private Font font;
    private GridPane root;
    private ButtonType result = ButtonType.CANCEL;

    private void createProductText() {
        Label name = new Label("Product name:");
        name.setFont(font);
        root.add(name, 0, 1);
        name_prEdit= new TextField();
        name_prEdit.setFont(Font.font(24));
        name_prEdit.setText(pr.getName_product());
        root.add(name_prEdit, 1, 1);
        if(pr!=null){
            name_prEdit.setText(pr.getName_product());
        }
    }

    private void createGenerationText() {
        Label nameG = new Label("Manufacturer's name:");
        nameG.setFont(font);
        root.add(nameG, 0, 2);
        name_genEdit = new TextField();
        name_genEdit.setFont(Font.font(24));
        name_genEdit.setText(pr.getName_generator());
        root.add(name_genEdit, 1, 2);
        if(pr!=null){
            name_genEdit.setText(pr.getName_generator());
        }
    }

    private void createSpinner() {
        Label pricce = new Label("Price:");
        pricce.setFont(font);
        root.add(pricce, 0, 3);
        if(pr!=null)
            priceEdit=new Spinner<>(0, 1000, pr.getPrice(),0.2);
        else
            priceEdit=new Spinner<>(0, 1000, 0);

        priceEdit.setStyle("-fx-font-size: 24 pt");
        priceEdit.setEditable(true);
        root.add(priceEdit, 1, 3);

    }

    private void createSText() {
        Label s = new Label("Product description:");
        s.setFont(font);
        root.add(s, 0, 4);
        speEdit = new TextField();
        speEdit.setFont(Font.font(24));
        speEdit.setText(pr.getSpecification());
        root.add(speEdit, 1, 4);
        if(pr!=null){
            speEdit.setText(pr.getSpecification());
        }
    }

    private void createButtons() {
        Button btnOk = new Button("Ok");
        btnOk.setFont(Font.font(24));
        root.add(btnOk, 0, 5);
        btnOk.setOnAction((ActionEvent e) -> handleOk());

        Button btnCancel = new Button("Cancel");
        btnCancel.setFont(Font.font(24));
        root.add(btnCancel, 1, 5);
        btnCancel.setOnAction((ActionEvent e) -> {
            handleCancel();
        });
    }

    public ProductEditDialog(Product p,String title) {
        this.pr = p;
        dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle(title);

        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(10);
        root.setVgap(10);
        font = Font.font("Tahoma", FontWeight.NORMAL, 20);

        createProductText();
        createGenerationText();
        createSText();
        createSpinner();
        createButtons();

        Scene scene = new Scene(root, 600, 500);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void handleOk() {
        pr.setName_product(name_prEdit.getText());
        pr.setName_generator(name_genEdit.getText());
        pr.setPrice(priceEdit.getValue());
        pr.setSpecification(speEdit.getText());
        result = ButtonType.OK;
        dialog.close();
    }

    private void handleCancel() {
        pr=null;
        result = ButtonType.CANCEL;
        dialog.close();
    }

    public ButtonType getResult() {
        return result;
    }

}
