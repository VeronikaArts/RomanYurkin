package temperature1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.XYChart;

public class Month {
    int []A = new int[] {-2, -5, -2, -4, 3, -6, -2, -1, 5, 1,
            1, 0, -1, 0, 3, -1, 2, 5, 2, 4, 4, 0, 6, 1, 4, 6, -1, 2, 4, 7, 11};

    public Month(){
       return;
    }

    public String getName(){
        return "График температуры за март";
    }

    public  XYChart.Series getSeries(){
        ObservableList<XYChart.Data> temperature = FXCollections.observableArrayList();

        for (int i = 0; i < A.length; i++) {
            temperature.add(new XYChart.Data(i+1, A[i]));
        }
        XYChart.Series series = new XYChart.Series();
        series.setName("March");
        series.setData(temperature);
        return series;
    }

    public int getT0(){
        int count=0;
        for (int i=0; i<A.length; i++){
            if (A[i]==0)
                count++;
        }
        return count;
    }

    public int getT1(){
        int count=0;
        for (int i=0; i<A.length; i++){
            if (A[i]>0)
                count++;
        }
        return count;
    }
    public int getT_1(){
        int count=0;
        for (int i=0; i<A.length; i++){
            if (A[i]<0)
                count++;
        }
        return count;
    }



}
