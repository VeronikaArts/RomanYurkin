package pets7;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ViewPet {
    private Pet pet;
    private GridPane grid;
    private Text kindPet;
    private Text namePet;
    private Text yearPet;
    private Text monthPet;
    private Text nameMaster;


    private void createPane(){
        grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Label kind = new Label("���: ");
        kind.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(kind, 0, 0);

        kindPet = new Text();
        kindPet.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        kindPet.setOnMouseMoved( (MouseEvent me)->{
            kindPet.setFill(Color.RED);
        });
        grid.add(kindPet, 1, 0);

        Label nameH = new Label("��� �������: ");
        nameH.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(nameH, 0, 1);

        namePet = new Text();
        namePet.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        namePet.setOnMouseMoved( (MouseEvent me)->{
            namePet.setFill(Color.RED);
        });
        grid.add(namePet, 1, 1);

        Label year = new Label("���������� ������ ���: ");
        year.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(year, 0, 3);

        yearPet = new Text();
        yearPet.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(yearPet, 1, 3);

        Label month = new Label("�������: ");
        month.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(month, 0, 4);

        monthPet = new Text();
        monthPet.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(monthPet, 1, 4);


        Label Veronika = new Label("��� �������: ");
        Veronika.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(Veronika, 0, 5);

        nameMaster = new Text();
        nameMaster.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
        grid.add(nameMaster, 1, 5);

        grid.setFocusTraversable(true);

        grid.setOnKeyPressed((KeyEvent ke )->{
            if (ke.getCode()==KeyCode.L && ke.isControlDown()){
                kind.setFont(Font.font("Tahoma", 32));
                kindPet.setFont(Font.font("Tahoma", 32));
                nameH.setFont(Font.font("Tahoma", 32));
                namePet.setFont(Font.font("Tahoma", 32));
                year.setFont(Font.font("Tahoma", 32));
                yearPet.setFont(Font.font("Tahoma", 32));
                month.setFont(Font.font("Tahoma", 32));
                monthPet.setFont(Font.font("Tahoma", 32));
                Veronika.setFont(Font.font("Tahoma", 32));
                nameMaster.setFont(Font.font("Tahoma", 32));

            }
            if (ke.getCode()==KeyCode.S && ke.isControlDown()){
                kind.setFont(Font.font("Tahoma", 16));
                kindPet.setFont(Font.font("Tahoma", 16));
                nameH.setFont(Font.font("Tahoma", 16));
                namePet.setFont(Font.font("Tahoma", 16));
                year.setFont(Font.font("Tahoma", 16));
                yearPet.setFont(Font.font("Tahoma", 16));
                month.setFont(Font.font("Tahoma", 16));
                monthPet.setFont(Font.font("Tahoma", 16));
                Veronika.setFont(Font.font("Tahoma", 16));
                nameMaster.setFont(Font.font("Tahoma", 16));

            }

        });


    }

    public GridPane getPane() {
        return grid;
    }

    public void setPet(Pet pet){
        this.pet = pet;
        kindPet.textProperty().bind(this.pet.kindStringProprty());
        namePet.textProperty().bind(this.pet.nameStringProperty());
        yearPet.textProperty().bind(this.pet.yearIntegerProperty().asString());
        monthPet.textProperty().bind(this.pet.monthIntegerProperty().asString());
        nameMaster.textProperty().bind(this.pet.host_nameStringProprty());

    }

    public ViewPet(Pet pet){
        createPane();
        setPet(pet);

    }


}