package pets8;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import java.io.*;
import java.util.ArrayList;
import java.util.stream.Collectors;


public class Main  extends Application {

    private TableView<Pet> table = new TableView<>();
    private String errorMessage="";

    private ObservableList<Pet> data= FXCollections.observableArrayList(
            new Pet ("������", "������", 1, 9, "���������"),
            new Pet ("�����", "�����", 0, 2, "������"));
    private void showMessage(String message){
        Alert mess = new Alert(Alert.AlertType.WARNING,message,ButtonType.OK);
    }


    private void handleFileOpen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Data File");
        File file = fileChooser.showOpenDialog(null);
        if (file == null) {
            return;
        }
        readDataFromFile(file);
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
    }

    private void readDataFromFile(File dataFile) {
        try {
            data.clear();
            errorMessage="";
            BufferedReader in = new BufferedReader(new FileReader(dataFile));
            String str;
            while ((str = in.readLine()) != null) {
                try {
                    if(str.isEmpty()) break;
                    String[] dataArray = str.split(" +");
                    if (dataArray.length != 5)
                        throw new Exception("wrong data");
                    String kind = dataArray[0];
                    String name = dataArray[1];
                    String master = dataArray[2];
                    int year = Integer.parseInt(dataArray[3]);
                    int month = Integer.parseInt(dataArray[4]);
                    Pet pet = new Pet(kind,name,year,month,master);
                    data.add(pet);
                } catch (Exception e){
                    errorMessage+=e.getMessage()+"\n";
                    in.close();
                }
            }
            in.close();
        } catch (IOException e){
            errorMessage+=e.getMessage()+"\n";
        }
    }


    private void handleFileSave() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Data File");
        File file = fileChooser.showSaveDialog(null);
        if (file == null) {
            return;
        }
        saveDataToFile(file);
    }
    private void saveDataToFile(File dataFile) {
        try {
            FileWriter out = new FileWriter(dataFile);
            for (Pet pet : data) {
                out.write(pet.getKind() + " " + pet.getName() + " "
                        + " " + pet.getHost_name() + " " +pet.getYear()
                        + " " + pet.getMonth()+ "\n");
            }
            out.close();
        } catch (IOException e){
            showMessage(e.getMessage());
        }
    }


    private void createTable() {

        TableColumn kindPetCol = new TableColumn("��� �������");
        kindPetCol.setMinWidth(150);
        kindPetCol.setCellValueFactory(new PropertyValueFactory<Pet, String>("kind"));
        kindPetCol.setCellFactory(TextFieldTableCell.forTableColumn());


        TableColumn namePetCol = new TableColumn("��� �������");
        namePetCol.setMinWidth(150);
        namePetCol.setCellValueFactory(new PropertyValueFactory<Pet, String>("name"));
        namePetCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn nameMasterCol = new TableColumn("��� ������� �������");
        nameMasterCol.setMinWidth(150);
        nameMasterCol.setCellValueFactory(new PropertyValueFactory<Pet, String>("host_name"));
        nameMasterCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn yearCol = new TableColumn("���������� ���");
        yearCol.setMinWidth(150);
        yearCol.setCellValueFactory(new PropertyValueFactory<Pet, Integer>("year"));
        yearCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        TableColumn monthCol = new TableColumn("���������� �������");
        monthCol.setMinWidth(150);
        monthCol.setCellValueFactory(new PropertyValueFactory<Pet, Integer>("month"));
        monthCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        table.setItems(data);
        table.getColumns().addAll(kindPetCol, namePetCol, nameMasterCol, yearCol, monthCol);
    }

    private void showPet(Pet pet) {
        Stage stage = new Stage();
        stage.setTitle("�������� ���������� � �������");
        BorderPane pane = new BorderPane();
        ViewPet viewPet = new ViewPet(pet);
        pane.setCenter(viewPet.getPane());
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.showAndWait();
    }


    private void handleButtonEdit() {
        Pet pet = table.getSelectionModel().getSelectedItem();
        if (pet != null) {
            PetEditDialog petEditDialog = new PetEditDialog(pet);
        } else {
            showMessage("������� �� ������");
        }
    }

    private void handleButtonAdd() {
        Pet pet= new Pet("", "", 0, 1,"");
        PetEditDialog petEdit=new PetEditDialog(pet);

        if (petEdit.getResult() == ButtonType.OK) {
            data.add(pet);
        }
    }

    private void handleButtonDelete() {
        int selectedIndex = table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            table.getItems().remove(selectedIndex);
        } else {
            showMessage("���������� ������� �������");
        }
    }

    private void handleButtonShow() {
        Pet pet = table.getSelectionModel().getSelectedItem();
        if (pet != null) {
            showPet(pet);
        } else {
            showMessage("������� �� ������");
        }
    }

    private Menu createFileMenu() {
        Menu fileMenu = new Menu("����");
        MenuItem open = new MenuItem("�������");
        MenuItem save = new MenuItem("���������");
        MenuItem exit = new MenuItem("�����");
        fileMenu.getItems().addAll(open, save, new SeparatorMenuItem(), exit);
        open.setOnAction((ActionEvent event) -> handleFileOpen());
        save.setOnAction((ActionEvent event) -> handleFileSave());
        exit.setOnAction((ActionEvent event) ->Platform.exit());
        return fileMenu;
    }

    private Menu createEditMenu() {
        Menu editMenu = new Menu("�������������");

        MenuItem add = new MenuItem("�������� �������");
        editMenu.getItems().add(add);
        add.setOnAction((ActionEvent event) -> handleButtonAdd());
        MenuItem edit = new MenuItem("������������� ����������");
        editMenu.getItems().add(edit);
        edit.setOnAction((ActionEvent event) -> handleButtonEdit());
        MenuItem delete = new MenuItem("������� �������");
        editMenu.getItems().add(delete);
        delete.setOnAction((ActionEvent event) -> handleButtonDelete());
        return editMenu;
    }

    private Menu createShowMenu() {
        Menu showMenu = new Menu("��������");

        MenuItem showPet = new MenuItem("�������� ���������� � �������");
        showPet.setOnAction((ActionEvent event) ->handleButtonShow());
        showMenu.getItems().add(showPet);

        MenuItem about = new MenuItem("�� ������");
        about.setOnAction((ActionEvent event) -> informAutor());
        showMenu.getItems().add(about);
        return showMenu;
    }

    private Menu createShowSortMenu() {
        Menu showMenu = new Menu("�����������");

        MenuItem showPet = new MenuItem("�������� �������� ������ ����");
        showPet.setOnAction((ActionEvent e) -> {
            Pet pet = table.getSelectionModel().getSelectedItem();
            if (pet != null) {
                ObservableList<Pet> dataFilter = FXCollections.observableArrayList();
                dataFilter.setAll(data.stream().filter(organization -> organization.isTheTypePet(pet)).collect(Collectors.toList()));
                dataFilterView(dataFilter);
            } else {
                showMessage("������� �� ������");
            }
        });
        showMenu.getItems().add(showPet);
        return showMenu;
    }

    private void createTable1(TableView<Pet> table1,ObservableList<Pet> dataFilter) {

        TableColumn kindPetCol = new TableColumn("��� �������");
        kindPetCol.setMinWidth(150);
        kindPetCol.setCellValueFactory(new PropertyValueFactory<Pet, String>("kind"));
        kindPetCol.setCellFactory(TextFieldTableCell.forTableColumn());


        TableColumn namePetCol = new TableColumn("��� �������");
        namePetCol.setMinWidth(150);
        namePetCol.setCellValueFactory(new PropertyValueFactory<Pet, String>("name"));
        namePetCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn nameMasterCol = new TableColumn("��� ������� �������");
        nameMasterCol.setMinWidth(150);
        nameMasterCol.setCellValueFactory(new PropertyValueFactory<Pet, String>("host_name"));
        nameMasterCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn yearCol = new TableColumn("���������� ���");
        yearCol.setMinWidth(150);
        yearCol.setCellValueFactory(new PropertyValueFactory<Pet, Integer>("year"));
        yearCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        TableColumn monthCol = new TableColumn("���������� �������");
        monthCol.setMinWidth(150);
        monthCol.setCellValueFactory(new PropertyValueFactory<Pet, Integer>("month"));
        monthCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        table1.setItems(dataFilter);
        table1.getColumns().addAll(kindPetCol, namePetCol, nameMasterCol, yearCol, monthCol);
    }
    private void dataFilterView (ObservableList<Pet> dataFilter){
        Stage view = new Stage();
        view.setTitle(dataFilter.get(0).getKind());
        TableView<Pet> table1 = new TableView<>();
        createTable1(table1,dataFilter);
        table1.setItems(dataFilter);
        Button ok = new Button("Ok");
        ok.setOnAction( e-> view.close());

        VBox root = new VBox();
        root.setPadding(new Insets(10));
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(table1, ok);
        view.setScene(new Scene(root, 800, 450));
        view.show();
    }

    @Override
    public void init() {
        readDataFromFile(new File("src/main/java/pets8/out.txt"));
    }

    private void informAutor() {

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("����� ������");
        alert.setHeaderText(null);
        alert.setContentText("����������� ��������\n ���-21��\n ����� �����, ������� � ���� �������������;)");


        alert.getDialogPane().setMinSize(200, 200);
        alert.showAndWait();

    }
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        if(!errorMessage.isEmpty()) showMessage(errorMessage);
        primaryStage.setTitle("�������");

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(5));


        createTable();
        table.setItems(data);
        root.setCenter(table);

        root.setTop(new MenuBar(createFileMenu(), createEditMenu(), createShowMenu(),createShowSortMenu()));



        /*ImageView imv = new ImageView(new Image(getClass().getResourceAsStream("images/pic.jpeg")))
        Label label = new Label();
        label.setGraphic(imv);*/



        Scene scene = new Scene(root, 820, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
